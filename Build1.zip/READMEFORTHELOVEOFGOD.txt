Ok so this is a very unpolished build. I'm aware it is missing menus, music, hit effects,
complex camera movement, npcs, etc.
Instead of thinking about what is missing, focus more on what is present (like how it feels to jump and such).

What I would appreciate:
(Text me or email michaelespo2@gmail.com, whatever is easiest)
(Answer as many or as few as you'd like) (I need negative feedback too)
Did you find any bugs?
What do you like?
What do you dislike or what feels weird?
Was there a moment where you tried to do something only to realize it doesn't work?
Would you change any health, stamina, damage, speed, etc.
Do you have any thoughts regarding interactions (hitboxes, collisions, etc)?
Do you have any ideas you would like to see implemented?

How to play:
WASD movement, Space to jump
Left Click to attack
Right Click OR J to throw shield, hit button again to create a platform
B to block, parry with Right Click or J
E to grab a ledge while falling, then use E, forward, or space to get off ledge

For testing purposes, "dying" refills your health. Getting to the next room refills it with enemies.
Fully depleting your stamina will negatively impact your character until it is completely refilled.

Follow my twitter if you want to be reminded I exist 3 times per year @AffinityGame_